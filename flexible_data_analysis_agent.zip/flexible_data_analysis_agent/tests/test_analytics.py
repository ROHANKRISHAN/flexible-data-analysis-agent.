from pathlib import Path
import sys
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analytics import load_dataset, profile_dataset, grouped_analysis, answer_question, time_analysis

DATA=Path(__file__).resolve().parents[1]/"data"/"demo_dataset.csv"

def test_no_fixed_column_names():
    df=load_dataset(str(DATA))
    p=profile_dataset(df)
    assert "NetSalesAmount" in p["numeric_columns"]
    assert "PurchaseTimestamp" in p["date_columns"]
    assert "MarketArea" in p["categorical_columns"]

def test_grouped_analysis_with_custom_names():
    df=load_dataset(str(DATA))
    result=grouped_analysis(df,"MarketArea","NetSalesAmount","sum")
    assert "MarketArea" in result.columns
    assert "sum_NetSalesAmount" in result.columns

def test_question_router_uses_actual_schema():
    df=load_dataset(str(DATA))
    result=answer_question(df,"compare NetSalesAmount by MarketArea")
    assert result["mode"]=="offline"
    assert result["plan"]["metric"]=="NetSalesAmount"
    assert result["plan"]["dimension"]=="MarketArea"

def test_time_analysis():
    df=load_dataset(str(DATA))
    result=time_analysis(df,"PurchaseTimestamp","NetSalesAmount","sum")
    assert "Period" in result.columns
